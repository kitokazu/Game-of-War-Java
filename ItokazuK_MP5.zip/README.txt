1)
Kai Itokazu
2344742
itokazu@chapman.edu
CPSC 231 - 03 Linstead
Mastery Project 5: Modern War(fare)

2) The main resources I used was the lectures.
I referred back to a lot of the code that was taught in your classes.
I also referred to the zybook, especially when it came to linkedlists.
I also used import java.util.Collections. I looked up a command Collections.shuffle
in order to shuffle the Linkedlist of cards in the pile. This was to prevent an infinite game.

3) No errors that I know of. I feel that my syntax could be much better though. 
And I would love to see the best way to do this project. 
I also put javadoc comments.

4) Worked on it by myself

5) Just running the assignment is all. There is no input from the user. 
To run it it is just javac Simulation.java and then java Simulation. The WarLogger.war file 
will have the simulation of the game. Also the war logger file has the war count and round count for each round. 
The statistics will be in the command line. Thank you!


